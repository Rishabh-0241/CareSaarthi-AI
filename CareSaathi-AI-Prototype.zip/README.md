# CareSaathi AI interactive prototype

Open `index.html` in a browser. No installation or build step is required.

Includes a responsive dashboard, medication tracker (add/mark taken), appointments (add), Care Circle, profile, and scripted AI-style demo assistant.

**Important:** This is a frontend-only prototype using sample data in browser memory. Firebase, Gemini, email/SMS, authentication, and Cloud Run are not connected. Do not enter real patient information. The demo assistant does not diagnose, prescribe, or change medication dosage.

For public hosting, upload `index.html` to a static host such as GitHub Pages, Netlify, or Cloudflare Pages. This is separate from the proposed FastAPI/Firebase/Gemini backend architecture.
